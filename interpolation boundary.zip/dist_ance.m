function d = dist_ance(set1,set2)
d = ((set1(1)-set2(1))^2 + (set1(2)-set2(2))^2)^0.5;
end